"""
Task 2: Exploratory Data Analysis (EDA)
Dataset: sample sales_data.csv
Run: python eda_analysis.py
"""
from pathlib import Path
import pandas as pd

DATA_FILE = Path(__file__).with_name("sales_data.csv")
df = pd.read_csv(DATA_FILE, parse_dates=["Date"])

print("=" * 60)
print("SALES DATA - EXPLORATORY DATA ANALYSIS")
print("=" * 60)

print("\n1. Dataset shape (rows, columns):")
print(df.shape)

print("\n2. First five rows:")
print(df.head())

print("\n3. Column data types:")
print(df.dtypes)

print("\n4. Missing values in each column:")
print(df.isnull().sum())

print("\n5. Duplicate rows:")
print(df.duplicated().sum())

print("\n6. Summary statistics:")
print(df.describe(include="all").to_string())

print("\n7. Total revenue by region (INR):")
region_revenue = df.groupby("Region")["Revenue_INR"].sum().sort_values(ascending=False)
print(region_revenue.to_string())

print("\n8. Revenue by product (INR):")
product_revenue = df.groupby("Product")["Revenue_INR"].sum().sort_values(ascending=False)
print(product_revenue.to_string())

print("\n9. Revenue by category (INR):")
category_revenue = df.groupby("Category")["Revenue_INR"].sum().sort_values(ascending=False)
print(category_revenue.to_string())

print("\n10. Monthly revenue (INR):")
df["Month"] = df["Date"].dt.to_period("M").astype(str)
monthly_revenue = df.groupby("Month")["Revenue_INR"].sum()
print(monthly_revenue.to_string())

print("\nKEY FINDINGS")
print(f"- Total recorded revenue: Rs. {df['Revenue_INR'].sum():,.0f}")
print(f"- Best-performing region: {region_revenue.idxmax()} "
      f"(Rs. {region_revenue.max():,.0f})")
print(f"- Best-performing product: {product_revenue.idxmax()} "
      f"(Rs. {product_revenue.max():,.0f})")
print(f"- Highest-revenue category: {category_revenue.idxmax()} "
      f"(Rs. {category_revenue.max():,.0f})")
print(f"- Average order-line revenue: Rs. {df['Revenue_INR'].mean():,.0f}")

# Save a cleaned copy for future use.
cleaned_file = Path(__file__).with_name("cleaned_sales_data.csv")
df.drop_duplicates().to_csv(cleaned_file, index=False)
print(f"\nCleaned dataset saved to: {cleaned_file.name}")

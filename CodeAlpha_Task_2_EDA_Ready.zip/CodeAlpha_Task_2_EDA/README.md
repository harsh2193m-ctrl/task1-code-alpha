# Task 2 — Exploratory Data Analysis (EDA)

## Objective
Explore a sample retail sales dataset to understand its structure, quality, and key business patterns.

## Tools
- Python
- Pandas

## Files
- `eda_analysis.py` — performs the analysis and prints results.
- `sales_data.csv` — included sample dataset.
- `requirements.txt` — Python libraries needed.

## How to run
1. Install Python 3.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python eda_analysis.py`

## Analysis performed
- Dataset size and first rows
- Column data types
- Missing-value and duplicate checks
- Summary statistics
- Revenue by region, product, and category
- Monthly revenue totals
- Saves `cleaned_sales_data.csv`

## Dataset note
This is a small, self-created sample dataset for learning and demonstration. It is not real company data.
